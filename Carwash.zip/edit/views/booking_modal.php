<!-- Custom CSS -->
<style>


    /* Gradient Button */
    .btn-gradient {
        background: linear-gradient(135deg, #4e54c8, #8f94fb);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #3b3f99, #6c70d8);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* Form styling */
    .form-label {
        font-size: 0.9rem;
        font-weight: 600;
        color: #444;
    }

    .form-control {
        border-radius: 10px;
        border: 1px solid #ddd;
        padding: 0.6rem 0.9rem;
        transition: 0.3s;
        background: #fff;
    }

    .form-control:focus {
        border-color: #6c63ff;
        box-shadow: 0 0 0 0.25rem rgba(108, 99, 255, 0.25);
    }

    /* Extra Services checkboxes */
    .form-check {
        margin-right: 1rem;
    }

    .form-check-input {
        accent-color: #6c63ff;
    }

    /* Textarea */
    #msg {
        height: 140px;
        resize: none;
    }

    /* Transition Hover (cards) */
    .transition-hover {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .transition-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }
</style>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-3 shadow-lg">

            <!-- Header -->
            <div class="modal-header bg-gradient text-white py-3 px-4" style="background: linear-gradient(135deg, #4e54c8, #8f94fb);">
                <h5 class="modal-title fw-bold" style="color: black; font-size:30px;">Car Wash Booking</h5>
                <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
            </div>

            <!-- Body -->
            <div class="modal-body p-4">
                <form action="../page/booking-modal.php?function=bookNow" method="POST" class="row g-3">

                    <!-- Package -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Package Type</label>
                        <select name="package_type" class="form-control" required>
                            <option value="">Select Package</option>
                            <option value="BASIC CLEANING">Basic Cleaning ($10.99)</option>
                            <option value="PREMIUM CLEANING">Premium Cleaning ($20.99)</option>
                            <option value="COMPLEX CLEANING">Complex Cleaning ($30.99)</option>
                        </select>
                    </div>

                    <!-- Washing Point -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Washing Point</label>
                        <select name="washing_point" class="form-control" required>
                            <option value="">Select Point</option>
                            <option value="Cielo Car Washing Point">Cielo Car Washing Point</option>
                            <option value="ABC Car Washing Point">ABC Car Washing Point</option>
                            <option value="Matrix Car Washing Point">Matrix Car Washing Point</option>
                            <option value="Pawing Car Wash Center">Pawing Car Wash Center</option>
                            <option value="Poto's War Wash">Poto's War Wash</option>
                            <option value="Julita Matrix Center Point">Julita Matrix Center Point</option>
                        </select>
                    </div>

                    <!-- Personal Info -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Full Name</label>
                        <input type="text" name="full_name" class="form-control" placeholder="John Doe" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="johndoe@email.com" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Mobile No.</label>
                        <input type="text" name="mobile_no" class="form-control" placeholder="0912345678" pattern="[0-9]{10}" title="10 numeric characters only" required>
                    </div>

                    <!-- Car Info -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Car Model</label>
                        <input type="text" name="car_model" class="form-control" placeholder="Toyota Vios 2023" required>
                    </div>

                    <!-- Date & Time -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Preferred Date</label>
                        <input type="date" name="wash_date" class="form-control" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Preferred Time</label>
                        <input type="time" name="wash_time" class="form-control" required>
                    </div>

                    <!-- Extra Services -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">Extra Services</label>
                        <div class="d-flex flex-wrap gap-3" name="extra">
                            <div><input type="checkbox" name="extra[]" value="Engine Wash"> Engine Wash</div>
                            <div><input type="checkbox" name="extra[]" value="Wax Coating"> Wax Coating</div>
                            <div><input type="checkbox" name="extra[]" value="Tire Polish"> Tire Polish</div>
                            <div><input type="checkbox" name="extra[]" value="Interior Vacuum"> Interior Vacuum</div>
                        </div>
                    </div>

                    <!-- Message -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">Message (Optional)</label>
                        <textarea id="msg" name="message" class="form-control" rows="3" placeholder="Any special requests?"></textarea>
                    </div>

                    <!-- Submit -->
                    <div class="col-12 d-grid">
                        <button type="submit" class="btn btn-gradient py-2 fw-bold">Confirm Booking</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script> <!-- Contact Javascript File -->
<script src="mail/jqBootstrapValidation.min.js"></script>
<script src="mail/contact.js"></script> <!-- Template Javascript -->
<script src="js/main.js"></script>