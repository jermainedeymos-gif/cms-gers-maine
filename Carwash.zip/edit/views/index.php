<?php
include("../nav/header.php");
?>

<link rel="stylesheet" href="../assets/header.css">
<link rel="stylesheet" href="../assets/custom.css">
<link rel="stylesheet" href="../assets/styles.css">
<link rel="stylesheet" href="http://192.168.80.168/cwms/css/style.css">
<div class="hero-banner">
    <h1>Carwash Management System</h1>
</div>


<?php
include("../carousel/carousel.php");
?>
<hr>


<!--Bootstrap Icons-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<!--Bootstrap cdn-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
<!--jquery-->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>


<!-- Why Choose Us -->
<section class="features py-5 text-center">
    <div class="container">
        <h2 class="fw-bold mb-5">Why Choose Us?</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <i class="bi bi-clock-history text-primary"></i>
                <h5 class="mt-3">Quick Service</h5>
                <p>We value your time. Get your car sparkling clean in minutes.</p>
            </div>
            <div class="col-md-4">
                <i class="bi bi-shield-check text-success"></i>
                <h5 class="mt-3">Trusted &amp; Safe</h5>
                <p>Our experts ensure your car is handled with care.</p>
            </div>
            <div class="col-md-4">
                <i class="bi bi-cash-coin text-warning"></i>
                <h5 class="mt-3">Affordable Prices</h5>
                <p>Premium cleaning packages without breaking the bank.</p>
            </div>
        </div>
    </div>
</section>

<!-- About Start -->
<div class="about">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-img">
                    <img src="https://cdn.prod.website-files.com/659c0ff8fc0ce612198bddd3/666898e4a26d9cb62ab0a3d8_image%2023%20copy.jpg" alt="Image">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="section-header text-left">
                    <p>About Us</p>
                    <h2>car washing and detailing</h2>
                </div>
                <div class="about-content">
                    <p>
                        At Hydro Brite Car Wash, we provide professional car washing and detailing services to keep your vehicle looking its best. We treat every car with care, focusing on quality, attention to detail, and customer satisfaction.<br>
                        Our services include seat washing, vacuum cleaning, interior wet cleaning, and window wiping, all done by trained staff using safe, effective products. Whether it’s a quick refresh or a deep clean, we’re here to help your car look and feel like new.
                    </p>
                    <ul>
                        <li><i class="far fa-check-circle"></i>Seats washing</li>
                        <li><i class="far fa-check-circle"></i>Vacuum cleaning</li>
                        <li><i class="far fa-check-circle"></i>Interior wet cleaning</li>
                        <li><i class="far fa-check-circle"></i>Window wiping</li>
                    </ul>
                    <a class="btn btn-custom" href="../sidenav/about.php">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>
<!-- About End -->

<!-- Services -->
<section class="container my-5" id="services">
    <h2 class="section-title">Our Services</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <div class="col">
            <div class="card shadow-lg text-center service-card h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                    <i class="bi bi-droplet-fill fs-1 text-primary mb-3"></i>
                    <h3 class="fw-bold">Exterior Wash</h3>
                    <p>Complete body wash using premium foam shampoo and hand drying for a spotless finish.</p>
                    <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#myModal" data-service="Exterior Wash">Book Now</button>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow-lg text-center service-card h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                    <i class="bi bi-brush-fill fs-1 text-primary mb-3"></i>
                    <h3 class="fw-bold">Interior Cleaning</h3>
                    <p>Vacuuming, dashboard polish, seat and carpet cleaning, leaving your interior fresh and spotless.</p>
                    <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#myModal" data-service="Interior Cleaning">Book Now</button>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow-lg text-center service-card h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                    <i class="bi bi-stars fs-1 text-primary mb-3"></i>
                    <h3 class="fw-bold">Full Detailing</h3>
                    <p>Complete interior and exterior detailing, including engine cleaning and protective coatings.</p>
                    <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#myModal" data-service="Full Detailing">Book Now</button>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow-lg text-center service-card h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                    <i class="bi bi-gear-fill fs-1 text-primary mb-3"></i>
                    <h3 class="fw-bold">Engine Cleaning</h3>
                    <p>Thorough engine wash and degreasing to improve performance and longevity.</p>
                    <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#myModal" data-service="Engine Cleaning">Book Now</button>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow-lg text-center service-card h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                    <i class="bi bi-sparkle fs-1 text-primary mb-3"></i>
                    <h3 class="fw-bold">Wax &amp; Polishing</h3>
                    <p>High-quality wax application to protect paint and enhance shine.</p>
                    <button class="btn btn-primary mt-auto" data-bs-toggle="modal" data-bs-target="#myModal" data-service="Wax &amp; Polishing">Book Now</button>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow-lg text-center service-card h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                    <i class="bi bi-circle-fill fs-1 text-primary mb-3"></i>
                    <h3 class="fw-bold">Tire &amp; Wheel Care</h3>
                    <p>Cleaning, polishing, and protection for wheels and tires to restore original luster.</p>
                    <button class="btn btn-primary mt-auto " data-bs-toggle="modal" data-bs-target="#myModal" data-service="Tire &amp; Wheel Care">Book Now</button>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Services -->

<!-- Service Start -->
<div class="service">
    <div class="container">
        <div class="section-header text-center">
            <p>What We Do?</p>
            <h2>Premium Washing Services</h2>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="service-item">
                    <img id="ss" src="https://autoimage.capitalone.com/cms/Auto/assets/images/1616-hero-pressure-wash-a-car.jpg" width="100px" height="100px" alt="">
                    <h3 id="h3">Exterior Washing</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="service-item">
                    <img id="ss" src="https://media.istockphoto.com/id/1288964234/photo/car-detailing-service-deep-interior-cleaning.jpg?s=612x612&w=0&k=20&c=O1jFEKtCipreEAIOhEkIwYxkq0OBd8rMYe8bOFPngtc=" width="100px" height="100px" alt="">
                    <h3 id="h3">Interior Washing</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="service-item">
                    <img id="ss" src="https://m.media-amazon.com/images/I/61w5rRSbt2S._UF1000,1000_QL80_.jpg" width="100px" height="100px" alt="">
                    <h3 id="h3">Vacuum Cleaning</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="service-item">
                    <img id="ss" src="https://motorgy.b-cdn.net/live/CarImages/cbaee914-c0b4-4be6-bfaf-98401be09249.webp" width="100px" height="100px" alt="">
                    <h3 id="sw">Seats Washing</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="service-item ">
                    <img id="ss" src="https://metroautoglass.com.au/wp-content/uploads/car-window-cleaning.jpg" width="100px" height="100px" alt="">
                    <h3 id="h3">Window Wiping</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="service-item">
                    <img id="ss" src="https://media.istockphoto.com/id/1287044692/photo/worker-washing-red-car-with-sponge-on-a-car-wash.jpg?s=612x612&w=0&k=20&c=_6WO9k1qkDub5CAEQgnORMduUoQJkU6w3jjVQTdTdwQ=" width="100px" height="100px" alt="">
                    <h3 id="wc">Wet Cleaning</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="service-item">
                    <img id="ss" src="https://www.communityautoinc.com/Files/EmailCampaigns/AdobeStock_251971442.jpeg" width="100px" height="100px" alt="">
                    <h3 id="wc">Oil Changing</h3>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="service-item">
                    <img id="ss" src="https://www.boschcarservice.com/xrm/media/services/brake_service_image_640w_360h.jpg" width="100px" height="100px" alt="">
                    <h3 id="bp">Brake Reparing</h3>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>
<!-- Service End -->


<!-- Price Start -->
<div class="price ">
    <div class="container">
        <div class="section-header text-center">
            <p>Washing Plan</p>
            <h2>Choose Your Plan</h2>
        </div>
        <div class="row ">
            <div class="col-md-4 ">
                <div class="price-item">
                    <div class="price-header">
                        <h3>Basic Cleaning</h3>
                        <h2><span>$</span><strong>10</strong><span>.99</span></h2>
                    </div>
                    <div class="price-body">
                        <ul>
                            <li><i class="far fa-check-circle"></i>Seats Washing</li>
                            <li><i class="far fa-check-circle"></i>Vacuum Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Exterior Cleaning</li>
                            <li><i class="far fa-times-circle"></i>Interior Wet Cleaning</li>
                            <li><i class="far fa-times-circle"></i>Window Wiping</li>
                        </ul>
                    </div>
                    <script>
                        $(document).on("click", "#myModal", function() {
                            $("myModal").show();
                        })
                    </script>
                    <div class="price-footer">
                        <a class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#myModal">Book Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="price-item featured-item">
                    <div class="price-header">
                        <h3>Premium Cleaning</h3>
                        <h2><span>$</span><strong>15</strong><span>.99</span></h2>
                    </div>
                    <div class="price-body">
                        <ul>
                            <li><i class="far fa-check-circle"></i>Seats Washing</li>
                            <li><i class="far fa-check-circle"></i>Vacuum Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Exterior Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Interior Wet Cleaning</li>
                            <li><i class="far fa-times-circle"></i>Window Wiping</li>
                        </ul>
                    </div>
                    <div class="price-footer">
                        <a class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#myModal">Book Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="price-item">
                    <div class="price-header">
                        <h3>Complex Cleaning</h3>
                        <h2><span>$</span><strong>20</strong><span>.99</span></h2>
                    </div>
                    <div class="price-body">
                        <ul>
                            <li><i class="far fa-check-circle"></i>Seats Washing</li>
                            <li><i class="far fa-check-circle"></i>Vacuum Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Exterior Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Interior Wet Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Window Wiping</li>
                        </ul>
                    </div>
                    <div class="price-footer">
                        <a class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#myModal">Book Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Price End -->

<?php include './booking_modal.php';
?>

<!-- Contact Section -->
<section id="contact" class="py-5 bg-light">
    <div class="container text-center">
        <h2 class="fw-bold mb-4">Get in Touch</h2>
        <p>📍 Pawing, Leyte, Philippines</p>
        <p>📞 0912-345-6789 | ✉️ carwash-rdbms.com</p>
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3889.438061336476!2d124.965228875329!3d11.032345991789592!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33051c3e8c8f2b0f%3A0x1b82ec6d7d2c9a21!2sPawing%20Leyte%2C%20Philippines!5e0!3m2!1sen!2sus!4v1695600000000!5m2!1sen!2sus"
            width="100%" height="300"></iframe>
    </div>
</section>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>

<!-- Contact Javascript File -->
<script src="mail/jqBootstrapValidation.min.js"></script>
<script src="mail/contact.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>

<?php
include("../nav/footer.php");
?>