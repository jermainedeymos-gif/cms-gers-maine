<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

<!-- Bootstrap 4 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<!-- FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">

<!-- DataTables (Bootstrap 4 integration) -->
<link href="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.css" rel="stylesheet">

<style>
    body {
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
        min-height: 100vh;
    }

    .nav-link.active {
        background-color: #0d6efd !important;
        color: #fff !important;
        font-weight: 600;
    }

    .nav-link:hover {
        background-color: rgba(255, 255, 255, 0.15);
        transition: 0.3s ease;
    }

    main {
        min-height: 100vh;
        background: #f8f9fa;
        padding: 20px;
    }
</style>

<!-- Custom CSS -->
<style>
    /* ---------- GLOBAL ---------- */
    body {
        font-family: 'Segoe UI', sans-serif;
        line-height: 1.6;
        scroll-behavior: smooth;
    }

    a {
        text-decoration: none;
    }

    /* ---------- NAVBAR ---------- */
    .navbar-dark .navbar-nav .nav-link {
        color: #fff;
        transition: color 0.3s;
    }

    .navbar-dark .navbar-nav .nav-link:hover {
        color: #ffc107;
    }

    .navbar-brand svg {
        fill: #fff;
    }

    /* ---------- HERO ---------- */
    .hero {
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4') center/cover no-repeat;
        color: #fff;
        text-align: center;
        padding: 120px 15px;
    }

    .hero h1 {
        font-size: 3rem;
        font-weight: 700;
    }

    .hero p {
        font-size: 1.2rem;
    }

    .btn-warning {
        font-weight: 600;
        border-radius: 50px;
        padding: 0.7rem 1.5rem;
    }

    /* ---------- WHY CHOOSE US ---------- */
    .features i {
        font-size: 2.5rem;
        margin-bottom: 15px;
    }

    /* ---------- SERVICES ---------- */
    .services .card {
        border: none;
        border-radius: 16px;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .services .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    /* ---------- STATS ---------- */
    .stats {
        color: #fff;
        text-align: center;
    }

    .stats h2 {
        font-size: 2rem;
        font-weight: 700;
    }

    .stats p {
        font-size: 1rem;
    }

    /* ---------- PRICING ---------- */
    .price {
        background: #f9f9f9;
        padding: 60px 0;
    }

    .price-item {
        border-radius: 16px;
        background: #fff;
        transition: all 0.3s;
        padding: 30px 20px;
    }

    .price-item:hover {
        transform: translateY(-8px);
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
    }

    .featured-item {
        border: 2px solid #6C63FF;
    }

    .featured-item h2 {
        color: #6C63FF;
    }

    .price-item ul li {
        padding: 0.6rem 0;
        border-bottom: 1px solid #f0f0f0;
    }

    .btn-gradient {
        background: linear-gradient(135deg, #4e54c8, #8f94fb);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #3b3f99, #6c70d8);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* ---------- TESTIMONIALS ---------- */
    blockquote {
        font-size: 1.1rem;
        font-style: italic;
    }

    /* ---------- CONTACT ---------- */
    iframe {
        border: none;
        border-radius: 16px;
    }

    /* ---------- FOOTER ---------- */
    .footer {
        background: #212529;
        color: #fff;
        padding: 30px 0;
    }

    .footer p {
        margin: 0;
    }
</style>

<!-- Custom CSS -->
<style>
    .sidebar {
        height: 100vh;
    }

    .sidebar .nav-link.active {
        background: rgba(255, 255, 255, 0.1);
        font-weight: bold;
    }

    .card {
        border-radius: 12px;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php include "./sidebar.php"; ?>

        <!-- Main Content -->
        <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h4 class="text-primary">Clients Management</h4>
                <div>
                    <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
                        <i class="fas fa-user-plus"></i> Add User
                    </button>
                    <button class="btn btn-success btn-sm">
                        <i class="fas fa-file-excel"></i> Export
                    </button>
                </div>
            </div>

            <!-- DataTable -->
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="userTable" class="table table-striped table-bordered table-hover text-center">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Messages</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                require_once "../model/booking-modal.php";

                                // ================= Fetch Bookings ================= //
                                $bookingsobj = new booking();
                                $bookings = $bookingsobj->getAllBookings();
                                ?>

                                <?php //for ($i = 1; $i <= 100; $i++): 
                                ?>
                                <?php foreach ($bookings as $b): ?>
                                    <tr style="text-align: justify;">
                                        <td> <?= $b['id']; ?></td>
                                        <td> <?= $b['name_tb']; ?></td>
                                        <td> <?= $b['email_tb']; ?></td>
                                        <td> <?= $b['message_tb']; ?></td>
                                        <td> <?= $b['sched_tb'] ?></td>
                                        <td>
                                            <a href="http://localhost/Cabelin/edit/admin/bookings.php" class="text-success mx-1">
                                                <i class="fa-solid fa-eye" style="margin-left: 40%;"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php //endfor; 
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- DataTables Init -->
<script>
    $(document).ready(function() {
        var table = $("#userTable").DataTable({
            dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                '<"row"<"col-sm-12"tr>>' +
                '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7 d-flex justify-content-end"p>>'
        });

        // Style pagination buttons with Bootstrap
        table.on('draw', function() {
            $('.dataTables_paginate .paginate_button').addClass('btn btn-primary btn-sm mx-1');
            $('.dataTables_paginate .paginate_button.current')
                .removeClass('btn-primary')
                .addClass('btn-dark');
        });
    });
</script>