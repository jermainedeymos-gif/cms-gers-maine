<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <!-- FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">

    <!-- datatables.net/download -->
    <link href="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.css" rel="stylesheet" integrity="sha384-Rpg3bXu+bDYBAmz2hkVQ7qtSDQPU6LeAGrdLhtW4dIkgZv9wSjPVkt8zLReOA9bn" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <!-- =====> Navigation Bar <===== -->
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">Carwash-RDBMS</a>

        <!-- Toggler/collapsibe Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto"> <!-- ml-auto moves the ul or the navbar to the right-->
                <li class="nav-item">
                    <a class="nav-link" href="#">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Bookings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Pages</a>
                </li>
            </ul>
        </div>
    </nav>


    <!-- =====> DataBase Table <===== -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- (text-center) moves the text to the center (text-success) change the text color to green 
                     (font-weight-normal) make the text as normal (my-5) space above the text-->
                <h4 class="text-center text-success font-weight-normal my-5">
                    CRUD Application Using Bootstrap4, PHP-OOP PDO-MySQL, Ajax, DataTable & SweetAlert2
                </h4>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <h4 class="mt-2 text-primary">All users in database!</h4>
            </div>
            <div class="col-lg-6">
                <button class="btn btn-primary m-1 float-right" data-toggle="modal" data-target="#addModal">
                    <i class="fas fa-user-plus fa-lg"></i>&nbsp;&nbsp;
                    Add New Users
                </button>
                <a href="" class="btn btn-success m-1 float-right">
                    <i class="fas fa-table fa-lg"></i>&nbsp;&nbsp;
                    Export to Excel
                </a>
            </div>
        </div>
        <hr class="my-1">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive" id="showUser">
                    <table class="table table-stiped table-sm table-bordered">
                        <thead>
                            <tr class="text-center">
                                <th>Id</th>
                                <th>First Name </th>
                                <th>Last Name</th>
                                <th>E-mail</th>
                                <th>Phone</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for ($i = 1; $i <= 100; $i++): ?>
                                <tr class="text-center text-secondary">
                                    <td><?= $i ?></td>
                                    <td><?= $i ?>=> Jovanna<?= $i ?></td>
                                    <td><?= $i ?>=> Petito</td>
                                    <td><?= $i ?>=> jovannapetito@gmail.com</td>
                                    <td><?= $i ?>=> 09546358751</td>
                                    <td>
                                        <a href="" title="View Details" class="text-success">&nbsp;&nbsp;
                                            <i class="fas fa-info-circle fa-lg"></i>
                                        </a>

                                        <a href="" title="Edit" class="text-primary">&nbsp;&nbsp;
                                            <i class="fas fa-edit fa-lg"></i>
                                        </a>

                                        <a href="" title="Delete" class="text-danger">&nbsp;&nbsp;
                                            <i class="fas fa-trash-alt fa-lg"></i>
                                        </a>
                                    </td>
                                <?php endfor; ?>
                                </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- =====> Add New User Modal <===== -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Modal Heading</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body px-4">
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="text" name="fname" class="form-control" placeholder="First Name" require>
                        </div>
                        <div class="form-group">
                            <input type="text" name="lname" class="form-control" placeholder="Last Name" require>
                        </div>

                        <div class="form-group">
                            <input type="email" name="email" class="form-control" placeholder="E-mail" require>
                        </div>

                        <div class="form-group">
                            <input type="tel" name="phone" class="form-control" placeholder="Phone No." require>
                        </div>

                        <div class="form-group">
                            <input type="submit" name="insert" value="Add User" class="btn btn-danger btn-block">
                        </div>
                    </form>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>



    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Bootstrap Font Awesome 5 -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <!-- datatables.net/download -->
    <script src="https://cdn.datatables.net/v/dt/dt-2.3.4/datatables.min.js" integrity="sha384-X2pTSfom8FUa+vGQ+DgTCSyBZYkC1RliOduHa0X96D060s7Q//fnOh3LcazRNHyo" crossorigin="anonymous"></script>

    <!-- Sweetalert2.github.io -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- This is to create a database table paginations -->
    <script type="text/javascript">
        $(document).ready(function() {
            $("table").DataTable({
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                    '<"row"<"col-sm-12"tr>>' +
                    '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7 d-flex justify-content-end"p>>',
                renderer: 'bootstrap' // ensure Bootstrap pagination styling
            });
        });
    </script>


    <!--
        <script type="text/javascript">
                $(document).ready(function(){
                    $("table").DataTable();
                });
         </script>
    -->
</body>

</html>