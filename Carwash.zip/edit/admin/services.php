<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

<!-- Bootstrap 4 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<!-- FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">

<!-- DataTables (Bootstrap 4 integration) -->
<link href="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.css" rel="stylesheet">

<!-- Custom CSS -->
<style>
    /* ---------- GLOBAL ---------- */
    body {
        font-family: 'Segoe UI', sans-serif;
        line-height: 1.6;
        scroll-behavior: smooth;
    }

    a {
        text-decoration: none;
    }

    /* ---------- NAVBAR ---------- */
    .navbar-dark .navbar-nav .nav-link {
        color: #fff;
        transition: color 0.3s;
    }

    .navbar-dark .navbar-nav .nav-link:hover {
        color: #ffc107;
    }

    .navbar-brand svg {
        fill: #fff;
    }

    /* ---------- HERO ---------- */
    .hero {
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4') center/cover no-repeat;
        color: #fff;
        text-align: center;
        padding: 120px 15px;
    }

    .hero h1 {
        font-size: 3rem;
        font-weight: 700;
    }

    .hero p {
        font-size: 1.2rem;
    }

    .btn-warning {
        font-weight: 600;
        border-radius: 50px;
        padding: 0.7rem 1.5rem;
    }

    /* ---------- WHY CHOOSE US ---------- */
    .features i {
        font-size: 2.5rem;
        margin-bottom: 15px;
    }

    /* ---------- SERVICES ---------- */
    .services .card {
        border: none;
        border-radius: 16px;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .services .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    /* ---------- STATS ---------- */
    .stats {
        color: #fff;
        text-align: center;
    }

    .stats h2 {
        font-size: 2rem;
        font-weight: 700;
    }

    .stats p {
        font-size: 1rem;
    }

    /* ---------- PRICING ---------- */
    .price {
        background: #f9f9f9;
        padding: 60px 0;
    }

    .price-item {
        border-radius: 16px;
        background: #fff;
        transition: all 0.3s;
        padding: 30px 20px;
    }

    .price-item:hover {
        transform: translateY(-8px);
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
    }

    .featured-item {
        border: 2px solid #6C63FF;
    }

    .featured-item h2 {
        color: #6C63FF;
    }

    .price-item ul li {
        padding: 0.6rem 0;
        border-bottom: 1px solid #f0f0f0;
    }

    .btn-gradient {
        background: linear-gradient(135deg, #4e54c8, #8f94fb);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #3b3f99, #6c70d8);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* ---------- TESTIMONIALS ---------- */
    blockquote {
        font-size: 1.1rem;
        font-style: italic;
    }

    /* ---------- CONTACT ---------- */
    iframe {
        border: none;
        border-radius: 16px;
    }

    /* ---------- FOOTER ---------- */
    .footer {
        background: #212529;
        color: #fff;
        padding: 30px 0;
    }

    .footer p {
        margin: 0;
    }
</style>

<!-- Custom CSS -->
<style>
    .sidebar {
        height: 100vh;
    }

    .sidebar .nav-link.active {
        background: rgba(255, 255, 255, 0.1);
        font-weight: bold;
    }

    .card {
        border-radius: 12px;
    }
</style>


<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <?php include "./sidebar.php"; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Services & Plans</h1>
                <button class="btn btn-success btn-sm">+ Add Service</button>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="card shadow-sm p-3">
                        <h5>Basic Cleaning</h5>
                        <ul>
                            <li>Seats Washing</li>
                            <li>Vacuum Cleaning</li>
                            <li>Exterior Cleaning</li>
                        </ul>
                        <span class="badge bg-primary" data-toggle="modal" data-target="#myModal1">$10.99</span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm p-3">
                        <h5>Premium Cleaning</h5>
                        <ul>
                            <li>Seats Washing</li>
                            <li>Vacuum Cleaning</li>
                            <li>Exterior Cleaning</li>
                            <li>Interior Wet Cleaning</li>
                        </ul>
                        <span class="badge bg-success" data-toggle="modal" data-target="#myModal2">$15.99</span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm p-3">
                        <h5>Complex Cleaning</h5>
                        <ul>
                            <li>Seats Washing</li>
                            <li>Vacuum Cleaning</li>
                            <li>Exterior Cleaning</li>
                            <li>Interior Wet Cleaning</li>
                            <li>Window Wiping</li>
                        </ul>
                        <span class="badge bg-Warning" data-toggle="modal" data-target="#myModal3">$20.99</span>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
    #m1 {
        width: 100%;
        height: 5vh;
    }
</style>

<!-- Basic Cleaning Modal -->
<div class="modal fade" id="myModal1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="../page/priceModal-handler.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Basic Cleaning</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <table id="userTable" class="table table-striped table-bordered table-hover text-center">
                        <thead class="thead-dark">
                            <tr>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    $10.99
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Premium Cleaning Modal -->
<div class="modal fade" id="myModal2">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="../page/priceModal-handler.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Premium Cleaning</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <table id="userTable" class="table table-striped table-bordered table-hover text-center">
                        <thead class="thead-dark">
                            <tr>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    $15.99
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Complex Cleaning Modal -->
<div class="modal fade" id="myModal3">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="../page/priceModal-handler.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Complex Cleaning</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <table id="userTable" class="table table-striped table-bordered table-hover text-center">
                        <thead class="thead-dark">
                            <tr>
                                <th>price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    $20.99
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>