<?php
require_once "../model/booking-modal.php";

// ================= Fetch Bookings ================= //
$bookingsobj = new Booking();
$bookings = $bookingsobj->getAllBookings();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carwash Admin Panel</title>

    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
    <!-- DataTables -->
    <link href="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.css" rel="stylesheet">

    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            min-height: 100vh;
        }

        .nav-link.active {
            background-color: #0d6efd !important;
            color: #fff !important;
            font-weight: 600;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transition: 0.3s ease;
        }

        main {
            min-height: 100vh;
            background: #f8f9fa;
            padding: 20px;
        }

        #m1 {
            width: 100%;
            height: 5vh;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3 text-white">
                    <h5 class="px-3 mb-3">Carwash Admin Panel</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="./index.php">
                                <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./bookings.php">
                                <i class="fas fa-calendar-check mr-2"></i> Manage Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./clients.php">
                                <i class="fas fa-users mr-2"></i> Clients
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./services.php">
                                <i class="fas fa-list mr-2"></i> Services & Plans
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./reports.php">
                                <i class="fas fa-chart-line mr-2"></i> Reports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="./settings.php">
                                <i class="fas fa-cog mr-2"></i> Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="../views/index.php">
                                <i class="fas fa-sign-out-alt mr-2"></i> Log Out
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h4 class="text-primary">Bookings Management</h4>
                    <div>
                        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
                            <i class="fas fa-user-plus"></i> Add Booking
                        </button>
                        <button class="btn btn-success btn-sm">
                            <i class="fas fa-file-excel"></i> Export
                        </button>
                    </div>
                </div>

                <!-- DataTable -->
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="userTable" class="table table-striped table-bordered table-hover text-center">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Id</th>
                                        <th>Booking Type</th>
                                        <th>Location</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Messages</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $b): ?>
                                        <tr>
                                            <td><?= $b['id']; ?></td>
                                            <td><?= $b['booking_type']; ?></td>
                                            <td><?= $b['washing_point']; ?></td>
                                            <td><?= $b['name_tb']; ?></td>
                                            <td><?= $b['email_tb']; ?></td>
                                            <td><?= $b['message_tb']; ?></td>
                                            <td><?= $b['sched_tb']; ?></td>
                                            <td><?= $b['status_tb']; ?></td>
                                            <td>
                                                <!-- Info -->
                                                <a href="#" class="text-primary mx-1" data-toggle="modal" data-target="#modal<?= $b['id']; ?>">
                                                    <i class="fas fa-info-circle"></i>
                                                </a>

                                                <!-- Confirm Bookings -->
                                                <a href="#" class="text-info mx-1" data-toggle="modal" data-target="#confirmModal<?= $b['id']; ?>">
                                                <i class="fas fa-check-circle"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ========== MODALS ========== -->
                <?php foreach ($bookings as $b): ?>
                    <!-- Info Modal -->
                    <div class="modal fade" id="modal<?= $b['id']; ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Booking Info (<?= $b['name_tb']; ?>)</h5>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <table class="table table-bordered text-center">
                                        <tr>
                                            <th>Name</th>
                                            <td><?= $b['name_tb']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Email</th>
                                            <td><?= $b['email_tb']; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date</th>
                                            <td><?= $b['sched_tb']; ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Confirm Modal -->
                    <div class="modal fade" id="confirmModal<?= $b['id']; ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="../page/booking-modal.php?function=confirmBooking" method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Confirm Booking</h5>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $b['id']; ?>">
                                        <p>Are you sure you want to confirm booking for <strong><?= $b['name_tb']; ?></strong>?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" name="confirmBooking" class="btn btn-success">Confirm</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal<?= $b['id']; ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="../page/booking-handler.php?function=updateBooking" method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Edit Booking (<?= $b['name_tb']; ?>)</h5>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $b['id']; ?>">
                                        <div class="form-group">
                                            <label>Booking Type</label>
                                            <input type="text" name="booking_type" value="<?= $b['booking_type']; ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label>Location</label>
                                            <input type="text" name="washing_point" value="<?= $b['washing_point']; ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" name="name_tb" value="<?= $b['name_tb']; ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" name="email_tb" value="<?= $b['email_tb']; ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label>Message</label>
                                            <textarea name="message_tb" class="form-control"><?= $b['message_tb']; ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Date</label>
                                            <input type="date" name="sched_tb" value="<?= $b['sched_tb']; ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

            </main>
        </div>
    </div>

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/v/bs4/dt-2.3.4/datatables.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#userTable').DataTable();
        });
    </script>
</body>

</html>