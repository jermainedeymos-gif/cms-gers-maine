<?php
require_once "../model/booking-modal.php";

$booking = new Booking;
$bookings = $booking->getAllBookings();

// Count total bookings
$booking = new Booking();
$totalBookings = $booking->countBookings();
?>



<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

<!-- Custom CSS -->
<style>
    /* ---------- GLOBAL ---------- */
    body {
        font-family: 'Segoe UI', sans-serif;
        line-height: 1.6;
        scroll-behavior: smooth;
    }

    a {
        text-decoration: none;
    }

    /* ---------- NAVBAR ---------- */
    .navbar-dark .navbar-nav .nav-link {
        color: #fff;
        transition: color 0.3s;
    }

    .navbar-dark .navbar-nav .nav-link:hover {
        color: #ffc107;
    }

    .navbar-brand svg {
        fill: #fff;
    }

    /* ---------- HERO ---------- */
    .hero {
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://framerusercontent.com/assets/jPGmgjk0UnrlNS7OFk2YvyM4c.mp4') center/cover no-repeat;
        color: #fff;
        text-align: center;
        padding: 120px 15px;
    }

    .hero h1 {
        font-size: 3rem;
        font-weight: 700;
    }

    .hero p {
        font-size: 1.2rem;
    }

    .btn-warning {
        font-weight: 600;
        border-radius: 50px;
        padding: 0.7rem 1.5rem;
    }

    /* ---------- WHY CHOOSE US ---------- */
    .features i {
        font-size: 2.5rem;
        margin-bottom: 15px;
    }

    /* ---------- SERVICES ---------- */
    .services .card {
        border: none;
        border-radius: 16px;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .services .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    /* ---------- STATS ---------- */
    .stats {
        color: #fff;
        text-align: center;
    }

    .stats h2 {
        font-size: 2rem;
        font-weight: 700;
    }

    .stats p {
        font-size: 1rem;
    }

    /* ---------- PRICING ---------- */
    .price {
        background: #f9f9f9;
        padding: 60px 0;
    }

    .price-item {
        border-radius: 16px;
        background: #fff;
        transition: all 0.3s;
        padding: 30px 20px;
    }

    .price-item:hover {
        transform: translateY(-8px);
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
    }

    .featured-item {
        border: 2px solid #6C63FF;
    }

    .featured-item h2 {
        color: #6C63FF;
    }

    .price-item ul li {
        padding: 0.6rem 0;
        border-bottom: 1px solid #f0f0f0;
    }

    .btn-gradient {
        background: linear-gradient(135deg, #4e54c8, #8f94fb);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #3b3f99, #6c70d8);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    /* ---------- TESTIMONIALS ---------- */
    blockquote {
        font-size: 1.1rem;
        font-style: italic;
    }

    /* ---------- CONTACT ---------- */
    iframe {
        border: none;
        border-radius: 16px;
    }

    /* ---------- FOOTER ---------- */
    .footer {
        background: #212529;
        color: #fff;
        padding: 30px 0;
    }

    .footer p {
        margin: 0;
    }
</style>

<!-- Custom CSS -->
<style>
    .sidebar {
        height: 100vh;
    }

    .sidebar .nav-link.active {
        background: rgba(255, 255, 255, 0.1);
        font-weight: bold;
    }

    .card {
        border-radius: 12px;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php include "./sidebar.php"; ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard</h1>
            </div>

            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card text-white bg-primary mb-3 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Bookings</h5>
                            <p class="card-text fs-4"><?= htmlspecialchars($totalBookings['total']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-success mb-3 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Clients</h5>
                            <p class="card-text fs-4"><?= htmlspecialchars($totalBookings['total']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-warning mb-3 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Revenue</h5>
                            <p class="card-text fs-4">₱ 12,540</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-danger mb-3 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Services</h5>
                            <p class="card-text fs-4">6</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts + Latest Bookings -->
            <div class="row">
                <!-- Chart -->
                <div class="col-lg-7">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Bookings Trend</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="bookingsChart" height="150"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Latest Bookings Table -->
                <div class="col-lg-5">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Recent Bookings</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Client</th>
                                        <th>Service</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    require_once "../model/booking-modal.php";

                                    $bookings = new Booking();
                                    $booking = $bookings->getAllBookings();
                                    $latestBookings = array_slice($booking, 0, 3);
                                    ?>
                                    <?php
                                    foreach ($latestBookings as $l):
                                    ?>
                                        <tr>
                                            <td><?= $l['name_tb']; ?></td>
                                            <td><?= $l['booking_type']; ?></td>
                                            <td><?= $l['sched_tb']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <a href="bookings.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div> <!-- row -->
</div> <!-- container-fluid -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    const ctx = document.getElementById('bookingsChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Bookings',
                data: [12, 19, 8, 15, 22, 30, 25],
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13, 110, 253, 0.2)',
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
</div>
</div>