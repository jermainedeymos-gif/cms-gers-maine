<?php
require_once "db_connection.php";

class Modal extends Database
{
    private $conn;

    public function __construct()
    {
        // Use the parent connect method
        $this->conn = $this->connect();
    }

    /* =========================================================
       🔹 C - Create (Insert new booking)
    ========================================================== */
    public function addBooking($data)
    {
        $insert = "INSERT INTO booking_model 
            (booking_type, full_name, contact_no, car_model, booking_date, message, status) 
            VALUES 
            (:plan, :name, :contact, :carModel, :date, :message, :status)";
        
        $stmt = $this->conn->prepare($insert);
        $stmt->bindParam(":plan",       $data['booking_type']);
        $stmt->bindParam(":name",       $data['full_name']);
        $stmt->bindParam(":contact",    $data['contact_no']);
        $stmt->bindParam(":carModel",   $data['car_model']);
        $stmt->bindParam(":date",       $data['booking_date']);
        $stmt->bindParam(":message",    $data['message']);
        $stmt->bindParam(":status",     $data['status']); // ✅ add status

        return $stmt->execute();
    }

    /* =========================================================
       🔹 R - Read (Fetch all bookings)
    ========================================================== */
    public function getBookings()
    {
        $sql = "SELECT * FROM booking_tb ORDER BY id ASC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* =========================================================
       🔹 R - Read (Fetch one booking by ID)
    ========================================================== */
    public function getBookingById($id)
    {
        $sql = "SELECT * FROM booking_model WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC); // single row
    }

    /* =========================================================
       🔹 U - Update booking
    ========================================================== */
    public function updateBooking($id, $data)
    {
        $update = "UPDATE booking_model 
                   SET booking_type = :plan, 
                       full_name = :name, 
                       contact_no = :contact, 
                       car_model = :carModel, 
                       booking_date = :date, 
                       message = :message, 
                       status = :status
                   WHERE id = :id";

        $stmt = $this->conn->prepare($update);
        $stmt->bindParam(":plan",       $data['booking_type']);
        $stmt->bindParam(":name",       $data['full_name']);
        $stmt->bindParam(":contact",    $data['contact_no']);
        $stmt->bindParam(":carModel",   $data['car_model']);
        $stmt->bindParam(":date",       $data['booking_date']);
        $stmt->bindParam(":message",    $data['message']);
        $stmt->bindParam(":status",     $data['status']);
        $stmt->bindParam(":id",         $id, PDO::PARAM_INT);

        return $stmt->execute();
    }

    /* =========================================================
       🔹 D - Delete booking
    ========================================================== */
    public function deleteBooking($id)
    {
        $delete = "DELETE FROM booking_model WHERE id = :id";
        $stmt = $this->conn->prepare($delete);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    /* =========================================================
       🔹 Count bookings (for dashboard stats)
    ========================================================== */
    public function countBookings()
    {
        $sql = "SELECT COUNT(*) as total FROM booking_model";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ?? 0;
    }
}
