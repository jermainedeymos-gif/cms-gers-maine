<?php
require_once "db_connection.php";

class Contact extends Database {
    private $conn;

    public function __construct() {
        // just use parent::connect()
        $this->conn = $this->connect();
    }

    public function sendSMS($data) {
        $sql = "INSERT INTO contact_tb (name_tb, email_tb, subject_tb, message_tb) 
                VALUES (:name, :email, :subject, :message)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(":name", $data['name_tb']);
        $stmt->bindParam(":email", $data['email_tb']);
        $stmt->bindParam(":subject", $data['subject_tb']);
        $stmt->bindParam(":message", $data['message_tb']);
        return $stmt->execute();
    }

    public function getMessages() {
        $sql = "SELECT * FROM contact_tb";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
