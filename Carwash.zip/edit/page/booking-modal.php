<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../model/booking-modal.php";
session_start();

#------------------------------------------------------------------------#
$action['page'] = 'booking-modal';
$action['subpage'] = $_GET['subpage'] ?? 'booking';
#------------------------------------------------------------------------#

if (isset($_GET['function'])) {
    $handler = new activeUser($action);

    switch ($_GET['function']) {
        case 'addBooking':
            $handler->bookNow();
            break;
        case 'updateBooking':
            $handler->updateBooking();
            break;
        case 'confirmBooking':
            $handler->confirmBooking();
            break;
        default:
            new defaultUser($action);
    }
} else {
    new defaultUser($action);
}
#------------------------------------------------------------------------#

class defaultUser
{
    private $page, $subpage, $user;

    function __construct($page)
    {
        $this->page    = $page['page'];
        $this->subpage = $page['subpage'];
        $this->user    = new Booking();

        include "../admin/bookings.php"; // booking form
    }
}

#------------------------------------------------------------------------#
class activeUser
{
    private $page, $subpage, $user;

    function __construct($page)
    {
        $this->page    = $page['page'];
        $this->subpage = $page['subpage'];
        $this->user    = new Booking();

        $this->{$_GET['function']}();
    }

    // Add Booking
    function bookNow()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'booking_type'      => $_POST['package_type'] ?? '',
                'washing_point'     => $_POST['washing_point'] ?? '',
                'name_tb'           => $_POST['full_name'] ?? '',
                'email_tb'          => $_POST['email'] ?? '',
                'phone_no'          => $_POST['mobile_no'] ?? '',
                'car_model'         => $_POST['car_model'] ?? '',
                'message_tb'        => $_POST['message'] ?? '',
                'extra_services'    => $_POST['extra'] ?? '',
                'sched_tb'          => $_POST['wash_date'] ?? '',
                'wash_time'         => $_POST['wash_time'] ?? ''
            ];

            if ($this->user->addBooking($data)) {
                $_SESSION['bookNow'] = true;
                echo "<script>alert('Booking added successfully!');window.location.href='../views/index.php';</script>";
            } else {
                echo "<script>alert('Failed to add booking.');</script>";
            }
        }
    }

    // Update Booking
    function updateBooking()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'];
            $data = [
                'booking_type'      => $_POST['booking_type'],
                'washing_point'     => $_POST['washing_point'],
                'name_tb'           => $_POST['name_tb'],
                'email_tb'          => $_POST['email_tb'],
                'phone_no'          => $_POST['phone_no'] ?? '',
                'car_model'         => $_POST['car_model'] ?? '',
                'message_tb'        => $_POST['message_tb'],
                'extra_services'    => $_POST['extra_services'] ?? '',
                'sched_tb'          => $_POST['sched_tb'],
                'wash_time'         => $_POST['wash_time'] ?? ''
            ];

            if ($this->user->updateBooking($id, $data)) {
                echo "<script>alert('Booking updated successfully!');window.location.href='../admin/bookings.php';</script>";
            } else {
                echo "<script>alert('Failed to update booking.');</script>";
            }
        }
    }

    // Confirm Booking
    function confirmBooking()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'];
            if ($this->user->confirmBooking($id)) {
                echo "<script>alert('Booking confirmed!');window.location.href='../admin/bookings.php';</script>";
            } else {
                echo "<script>alert('Failed to confirm booking.');</script>";
            }
        }
    }

    // STATUS ACTIONS
    function conbk(){

        $up = $this->user->upconbk($_GET['up_id']);

        if ($up){
            echo '<script>alert("Update  successfully!");window.location.href="../admin/bookings.php";</script>';
        }else{
            echo '<script>alert("Failed to Update plsss try again.");window.location.href="../admin/bookings.php";</script>';
        }
        

         include "../admin/booking-modal.php"; // booking form
    }
}

