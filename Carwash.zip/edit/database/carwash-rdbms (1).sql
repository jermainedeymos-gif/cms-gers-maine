-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2025 at 05:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rdbms`
--
CREATE DATABASE IF NOT EXISTS `rdbms` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `rdbms`;

-- --------------------------------------------------------

--
-- Table structure for table `administrator_tb`
--

CREATE TABLE `administrator_tb` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_pass` varchar(1000) NOT NULL,
  `role` varchar(100) NOT NULL COMMENT 'Administrator'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrator_tb`
--

INSERT INTO `administrator_tb` (`id`, `user_name`, `user_pass`, `role`) VALUES
(3, 'admin', '$2y$10$O3bDBntk7Ml7JPSxRcG3O.ejo3erVmNSVc5iK3c4xY3cYpB5yjL7G', ''),
(4, 'shadow', '$2y$10$8H/m0Ino9syZeIBVsey/mOczTJhggQHWZ/5TRtn0IDd4TNL8x82aS', ''),
(5, 'admin', '$2y$10$QI8gOhsy0CWLGKa/AbKYzOEiS0z7/N47GkwZEKE4jghExCX6SU9T.', '');

-- --------------------------------------------------------

--
-- Table structure for table `booking_model`
--

CREATE TABLE `booking_model` (
  `id` int(11) NOT NULL,
  `booking_type` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `contact_no` bigint(50) NOT NULL,
  `car_model` varchar(100) NOT NULL,
  `booking_date` date NOT NULL,
  `message` varchar(1000) NOT NULL,
  `status` enum('Complete','Pending') NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_model`
--

INSERT INTO `booking_model` (`id`, `booking_type`, `full_name`, `contact_no`, `car_model`, `booking_date`, `message`, `status`) VALUES
(1, 'Full Detailing', 'johndoe', 988896548, 'Toyota', '2025-09-23', 'sana dumara', 'Pending'),
(2, 'Engine Cleaning', 'Jermaine Deymos', 2147483647, 'Honda', '2025-09-23', 'hahahahahha', 'Pending'),
(3, 'Interior Cleaning', 'jermaine deymos', 9567487689, 'Toyota', '2025-09-26', 'ewgeqryey', 'Pending'),
(4, 'Exterior Wash', 'jermaine deymos', 9567489675, 'Honda', '2025-09-23', 'hsgdshgdsye', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `contact_tb`
--

CREATE TABLE `contact_tb` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_tb`
--

INSERT INTO `contact_tb` (`id`, `user_name`, `user_email`, `subject`, `message`) VALUES
(1, 'johndoe', 'jermainedeymos@gmail.com', 'uyu', 'h'),
(20, 'johndoe', 'jermainedeymos@gmail.com', 'Math', 'gyfgyf'),
(21, 'jermaine deymos', 'maine@gmail.com', 'carwash', 'test 1'),
(22, 'jermaine deymos', 'jermainedeymos@gmail.com', 'carwash', 'awrqawerwer'),
(23, 'maine', 'jermainedeymos@gmail.com', 'carwash', 'test1'),
(24, 'Gers', 'ger@gmail.com', 'Carwash', 'Interior Washing'),
(25, 'Gers', 'sample@gmail.com', 'carwash', 'exterior washing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator_tb`
--
ALTER TABLE `administrator_tb`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_name` (`user_name`);

--
-- Indexes for table `booking_model`
--
ALTER TABLE `booking_model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_tb`
--
ALTER TABLE `contact_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator_tb`
--
ALTER TABLE `administrator_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `booking_model`
--
ALTER TABLE `booking_model`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact_tb`
--
ALTER TABLE `contact_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
