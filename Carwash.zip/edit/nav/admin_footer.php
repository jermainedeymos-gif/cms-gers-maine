<!--copy rights start here-->
<div class="copyrights">
                <p>© 2025 CWMS. All Rights Reserved | <a href="#">CWMS</a> </p>
            </div>