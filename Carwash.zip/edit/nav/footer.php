<!-- Footer Start -->
<div class="footer">
    <div class="container copyright">
        <h3 class="section-title text-light">Dashboard Preview</h3>
        <p>Get a quick overview of your business stats, social reach, and customer engagement in real time.</p>
        <div class="social-links">
            <a href="#"><i class="bi bi-facebook text-info"></i></a>
            <a href="#"><i class="bi bi-instagram text-warning"></i></a>
            <a href="#"><i class="bi bi-twitter text-danger"></i></a>
        </div>
        <br><br>
        <p>&copy; <?php echo date("Y/M/D"); ?> Carwash Management System</p>
    </div>
</div>
<!-- Footer End -->

