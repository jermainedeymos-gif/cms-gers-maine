<?php
include "../nav/header.php";
require_once "../model/modal-class.php";

$modal = new Modal();
$bookings = $modal->getBookings(); // Fetch lahat ng bookings

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Booking</title>

    <!--Bootstrap cdn-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

    <!-- External CSS -->
    <link rel="stylesheet" href="http://localhost/Cabelin/edit/assets/custom.css">
    <link rel="stylesheet" href="http://localhost/Cabelin/edit/assets/header.css">
    <link rel="stylesheet" href="http://localhost/Cabelin/edit/assets/styles.css">

    <style>
        /* ===== Title Styling Upgrade ===== */
        .container h1 {
            font-family: "Segoe UI", sans-serif;
            font-size: 32px;
            font-weight: 700;
            color: #263238;
            margin-top: 10px;
            margin-bottom: 25px;
            position: relative;
            display: inline-block;
            padding: 8px 15px;
            background: linear-gradient(135deg, #e3f2fd, #ffffff);
            border-radius: 8px;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
        }

        /* Underline Accent with Glow */
        .container h1::after {
            content: "";
            position: absolute;
            width: 60%;
            height: 4px;
            left: 20%;
            bottom: -6px;
            background: linear-gradient(135deg, #1976d2, #42a5f5);
            border-radius: 4px;
            box-shadow: 0 2px 6px rgba(25, 118, 210, 0.4);
        }

        /* ===== Booking Table Styles Upgrade ===== */
        .booking-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 30px;
            font-size: 15px;
            font-family: "Segoe UI", sans-serif;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
            animation: fadeIn 0.6s ease-in-out;
        }

        /* Header */
        .booking-table th {
            background: linear-gradient(135deg, #1a237e, #3949ab);
            color: #fff;
            padding: 15px 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.7px;
        }

        /* Rows */
        .booking-table td {
            padding: 13px 10px;
            border-bottom: 1px solid #eee;
            color: #333;
            transition: transform 0.2s;
        }

        /* Alternate Row */
        .booking-table tr:nth-child(even) {
            background: #f4f6f9;
        }

        /* Hover Effect */
        .booking-table tr:hover {
            background: #e8f0fe;
            transform: scale(1.01);
            box-shadow: inset 0 0 8px rgba(25, 118, 210, 0.2);
        }

        /* Status Badges */
        .status-pending,
        .status-approved {
            font-weight: bold;
            font-size: 15px;
            padding: 6px 12px;
            border-radius: 5px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 80px;
            text-align: center;
        }

        .status-pending {
            border-right: 10%;
            color: #c62828;
        }

        .status-approved {
            color: #2e7d32;
        }


        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body>
    <main class="container">
        <h1>Client Booking</h1>

        <table class="booking-table">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Booking Type</th>
                    <th>Full Name</th>
                    <th>Car Model</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($bookings)) {
                    foreach ($bookings as $index => $b) { ?>
                        <tr>
                            <td><?= htmlspecialchars($b['id']) ?></td>
                            <td><?= htmlspecialchars($b['booking_type']) ?></td>
                            <td><?= htmlspecialchars($b['name_tb']) ?></td>
                            <td><?= htmlspecialchars($b['car_model']) ?></td>
                            <td><?= htmlspecialchars($b['sched_tb']) ?></td>
                            <td class="<?= strtolower($b['status_tb']) == 'pending' ? 'status-pending' : 'status-approved' ?>">
                                <?= htmlspecialchars($b['status_tb']) ?>
                            </td>
                        </tr>
                    <?php }
                } else { ?>
                    <tr>
                        <td colspan="8">No bookings found.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>
</body>

</html>